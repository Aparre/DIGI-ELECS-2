/*
  74LS47 BCD to 7-Segment Decoder Library for Arduino

  This library provides functions to easily control a 7-segment display
  using a 74LS47 BCD to 7-segment decoder.

  Connections:
  - Arduino Digital Pins (e.g., 2, 3, 4, 5) to 74LS47 Input Pins (A, B, C, D)
  - 74LS47 Output Pins (a, b, c, d, e, f, g) to 7-Segment Display Segments (a, b, c, d, e, f, g)
  - 74LS47 LT (Lamp Test), RBI (Ripple Blanking Input), and BI/RBO (Blanking Input/Ripple Blanking Output) pins can be connected as needed.

  Example Usage:
  74LS47 display(2, 3, 4, 5); // Initialize with Arduino pins

  void setup() {
    display.begin();
  }

  void loop() {
    for (int i = 0; i < 10; i++) {
      display.displayNumber(i);
      delay(1000);
    }
  }
*/

#include "LS7447.h"


LS7447::LS7447(int pinA, int pinB, int pinC, int pinD) {
  _pinA = pinA;
  _pinB = pinB;
  _pinC = pinC;
  _pinD = pinD;
}

void LS7447::begin() {
  pinMode(_pinA, OUTPUT);
  pinMode(_pinB, OUTPUT);
  pinMode(_pinC, OUTPUT);
  pinMode(_pinD, OUTPUT);
  blankDisplay(); //Initialize display to blank.
}

void LS7447::displayNumber(int number) {
  if (number < 0 || number > 15) {
    blankDisplay(); // Display blank if number is out of range
    return;
  }

  digitalWrite(_pinA, bitRead(number, 0));
  digitalWrite(_pinB, bitRead(number, 1));
  digitalWrite(_pinC, bitRead(number, 2));
  digitalWrite(_pinD, bitRead(number, 3));
}

void LS7447::blankDisplay() {
  digitalWrite(_pinA, HIGH);
  digitalWrite(_pinB, HIGH);
  digitalWrite(_pinC, HIGH);
  digitalWrite(_pinD, HIGH);
}

void LS7447::lampTest(){
    digitalWrite(_pinA, LOW);
    digitalWrite(_pinB, LOW);
    digitalWrite(_pinC, LOW);
    digitalWrite(_pinD, LOW);
}