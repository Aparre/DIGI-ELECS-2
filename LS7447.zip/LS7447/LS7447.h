/*
  74LS47 BCD to 7-Segment Decoder Library for Arduino

  This library provides functions to easily control a 7-segment display
  using a 74LS47 BCD to 7-segment decoder.

  Connections:
  - Arduino Digital Pins (e.g., 2, 3, 4, 5) to 74LS47 Input Pins (A, B, C, D)
  - 74LS47 Output Pins (a, b, c, d, e, f, g) to 7-Segment Display Segments (a, b, c, d, e, f, g)
  - 74LS47 LT (Lamp Test), RBI (Ripple Blanking Input), and BI/RBO (Blanking Input/Ripple Blanking Output) pins can be connected as needed.

  Example Usage:
  74LS47 display(2, 3, 4, 5); // Initialize with Arduino pins

  void setup() {
    display.begin();
  }

  void loop() {
    for (int i = 0; i < 10; i++) {
      display.displayNumber(i);
      delay(1000);
    }
  }
*/
#ifndef LS7447_h
#define LS7447_h

#include "Arduino.h"

class LS7447 {
public:
  LS7447(int pinA, int pinB, int pinC, int pinD);
  void begin();
  void displayNumber(int number);
  void blankDisplay();
  void lampTest();

private:
  int _pinA;
  int _pinB;
  int _pinC;
  int _pinD;
};

#endif